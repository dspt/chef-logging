define(function (require) {
  var results = {};

  results.timeSeries = {
    data: {
      ordered: {
        date: true,
        interval: 600000,
        max: 1414437217559,
        min: 1414394017559
      }
    },
    label: 'apache',
    value: 44,
    point: {
      label: 'apache',
      x: 1414400400000,
      y: 44,
      y0: 0
    }
  };
});
