define(function (require) {
  return {
    meta: {
      index: 'logstash-*'
    }
  };
});
