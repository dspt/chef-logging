Kibana Plugins
==================

PLEASE DON'T WRITE CUSTOM PLUGINS

While Kibana has a directory called plugins, and a way to load plugin-provided modules, the API and underlying mechanisms are purposefully undocumented, and are very likely to change.

Issues filed to aid in the development of plugins will be closed with a link to this file.