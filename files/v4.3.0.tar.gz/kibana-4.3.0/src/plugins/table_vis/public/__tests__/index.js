describe('Table Vis', function () {
  require('./_table_vis_controller');
  require('./_table_vis');
});
