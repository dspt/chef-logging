describe('ParamTypes', function () {
  require('./_field');
  require('./_optioned');
  require('./_regex');
  require('./_string');
  require('./_raw_json');
});
